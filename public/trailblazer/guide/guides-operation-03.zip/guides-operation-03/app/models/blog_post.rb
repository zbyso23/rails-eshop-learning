#:model
class BlogPost < ActiveRecord::Base
end
#:model end
