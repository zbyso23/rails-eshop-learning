module Home
  module Cell
    class Layout < Trailblazer::Cell

    end
  end
end
